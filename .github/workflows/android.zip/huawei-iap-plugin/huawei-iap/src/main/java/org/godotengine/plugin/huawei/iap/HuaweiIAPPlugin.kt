package org.godotengine.plugin.huawei.iap

import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.util.Log
import com.huawei.hms.iap.Iap
import com.huawei.hms.iap.IapApiException
import com.huawei.hms.iap.IapClient
import com.huawei.hms.iap.entity.ConsumeOwnedPurchaseReq
import com.huawei.hms.iap.entity.OrderStatusCode
import com.huawei.hms.iap.entity.OwnedPurchasesReq
import com.huawei.hms.iap.entity.ProductInfoReq
import com.huawei.hms.iap.entity.PurchaseIntentReq
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject

/**
 * Godot Android plugin for Huawei HMS In-App Purchases.
 *
 * Exposes consumables, non-consumables and subscriptions:
 * - [checkEnvironment] verifies HMS Core / signed-in HUAWEI ID readiness.
 * - [queryProducts] fetches product details (prices) from AppGallery Connect.
 * - [purchase] opens the Huawei IAP checkout page for one product.
 * - [consumePurchase] consumes a delivered consumable.
 * - [queryOwnedPurchases] / [queryPurchaseHistory] restore previous purchases.
 *
 * All payloads are JSON strings; parse them in GDScript with JSON.parse_string().
 */
class HuaweiIAPPlugin(godot: Godot) : GodotPlugin(godot) {

    companion object {
        private val TAG = HuaweiIAPPlugin::class.java.simpleName

        /** Request code for the Huawei IAP checkout activity result. */
        private const val IAP_REQUEST_CODE = 0x4941 // "IA"

        /** Product types. Values match [IapClient.PriceType]. */
        const val TYPE_CONSUMABLE = 0
        const val TYPE_NON_CONSUMABLE = 1
        const val TYPE_SUBSCRIPTION = 2

        private val SIG_ENV_CHECKED = SignalInfo(
            "env_checked", java.lang.Boolean::class.java, String::class.java
        )
        private val SIG_PRODUCTS_RECEIVED = SignalInfo("products_received", String::class.java)
        private val SIG_PURCHASE_SUCCESS = SignalInfo("purchase_success", String::class.java)
        private val SIG_PURCHASE_CANCELLED = SignalInfo("purchase_cancelled")
        private val SIG_PURCHASE_FAILED = SignalInfo(
            "purchase_failed", java.lang.Integer::class.java, String::class.java
        )
        private val SIG_CONSUME_SUCCESS = SignalInfo("consume_success", String::class.java)
        private val SIG_CONSUME_FAILED = SignalInfo(
            "consume_failed", java.lang.Integer::class.java, String::class.java
        )
        private val SIG_OWNED_PURCHASES = SignalInfo("owned_purchases", String::class.java)
        private val SIG_IAP_ERROR = SignalInfo(
            "iap_error", java.lang.Integer::class.java, String::class.java
        )

        private val SIGNALS: Set<SignalInfo> = setOf(
            SIG_ENV_CHECKED,
            SIG_PRODUCTS_RECEIVED,
            SIG_PURCHASE_SUCCESS,
            SIG_PURCHASE_CANCELLED,
            SIG_PURCHASE_FAILED,
            SIG_CONSUME_SUCCESS,
            SIG_CONSUME_FAILED,
            SIG_OWNED_PURCHASES,
            SIG_IAP_ERROR,
        )
    }

    private var iapClient: IapClient? = null

    override fun getPluginName() = "HuaweiIAP"

    override fun getPluginSignals(): Set<SignalInfo> = SIGNALS

    /** Creates the HMS [IapClient]. Call once before any other method. */
    @UsedByGodot
    fun initialize(): Boolean {
        return try {
            val hostActivity = activity
            if (hostActivity == null) {
                Log.e(TAG, "initialize: activity is null, engine not ready yet")
                return false
            }
            iapClient = Iap.getIapClient(hostActivity)
            Log.i(TAG, "Huawei IAP client created")
            true
        } catch (e: Exception) {
            Log.e(TAG, "initialize: failed to create IAP client", e)
            emitSignal(SIG_IAP_ERROR, -1, "init failed: ${e.message}")
            false
        }
    }

    /**
     * Checks that HMS Core is available and the user can pay.
     * Emits `env_checked(ok, message)`.
     */
    @UsedByGodot
    fun checkEnvironment() {
        val client = requireClient() ?: return
        try {
            client.isEnvReady
                .addOnSuccessListener {
                    emitSignal(SIG_ENV_CHECKED, true, "ready")
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    Log.w(TAG, "checkEnvironment failed: $code $message")
                    emitSignal(SIG_ENV_CHECKED, false, "[$code] $message")
                }
        } catch (e: Exception) {
            emitSignal(SIG_ENV_CHECKED, false, e.message ?: "unknown error")
        }
    }

    /**
     * Queries product details for a comma-separated list of product ids.
     * Emits `products_received(json)` with `{"products":[{productId,price,...}]}`.
     */
    @UsedByGodot
    fun queryProducts(productIdsCsv: String, priceType: Int) {
        val client = requireClient() ?: return
        val ids = productIdsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (ids.isEmpty()) {
            emitSignal(SIG_IAP_ERROR, -1, "queryProducts: empty product list")
            return
        }
        try {
            val req = ProductInfoReq()
            req.priceType = priceType
            req.productIds = ids
            client.obtainProductInfo(req)
                .addOnSuccessListener { result ->
                    val products = JSONArray()
                    result?.productInfoList?.forEach { info ->
                        try {
                            products.put(
                                JSONObject()
                                    .put("productId", info.productId ?: "")
                                    .put("productName", info.productName ?: "")
                                    .put("productDesc", info.productDesc ?: "")
                                    .put("price", info.price ?: "")
                                    .put("currency", info.currency ?: "")
                                    .put("priceType", info.priceType)
                            )
                        } catch (parseError: Exception) {
                            Log.w(TAG, "Skipping unreadable product entry", parseError)
                        }
                    }
                    emitSignal(
                        SIG_PRODUCTS_RECEIVED,
                        JSONObject().put("products", products).toString()
                    )
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    emitSignal(SIG_IAP_ERROR, code, "queryProducts: $message")
                }
        } catch (e: Exception) {
            emitSignal(SIG_IAP_ERROR, -1, "queryProducts: ${e.message}")
        }
    }

    /**
     * Opens the Huawei IAP checkout page for [productId].
     * Emits `purchase_success(json)`, `purchase_cancelled()` or `purchase_failed(code, message)`.
     */
    @UsedByGodot
    fun purchase(productId: String, priceType: Int, developerPayload: String) {
        val client = requireClient() ?: return
        if (productId.isBlank()) {
            emitSignal(SIG_PURCHASE_FAILED, -1, "empty product id")
            return
        }
        try {
            val req = PurchaseIntentReq()
            req.productId = productId
            req.priceType = priceType
            req.developerPayload = developerPayload.ifEmpty { "godot-${System.currentTimeMillis()}" }
            client.createPurchaseIntent(req)
                .addOnSuccessListener { result ->
                    val status = result?.status
                    if (status != null && status.hasResolution()) {
                        val hostActivity = activity
                        if (hostActivity == null) {
                            emitSignal(SIG_PURCHASE_FAILED, -1, "activity unavailable")
                            return@addOnSuccessListener
                        }
                        hostActivity.runOnUiThread {
                            try {
                                status.startResolutionForResult(hostActivity, IAP_REQUEST_CODE)
                            } catch (e: SendIntentException) {
                                Log.e(TAG, "Failed to launch IAP checkout", e)
                                emitSignal(SIG_PURCHASE_FAILED, -1, "checkout launch failed")
                            }
                        }
                    } else {
                        emitSignal(SIG_PURCHASE_FAILED, -1, "no checkout intent returned")
                    }
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    emitSignal(SIG_PURCHASE_FAILED, code, message)
                }
        } catch (e: Exception) {
            emitSignal(SIG_PURCHASE_FAILED, -1, e.message ?: "unknown error")
        }
    }

    /**
     * Consumes a delivered consumable so it can be bought again.
     * Emits `consume_success(purchaseToken)` or `consume_failed(code, message)`.
     */
    @UsedByGodot
    fun consumePurchase(purchaseToken: String) {
        val client = requireClient() ?: return
        if (purchaseToken.isBlank()) {
            emitSignal(SIG_CONSUME_FAILED, -1, "empty purchase token")
            return
        }
        try {
            val req = ConsumeOwnedPurchaseReq()
            req.purchaseToken = purchaseToken
            client.consumeOwnedPurchase(req)
                .addOnSuccessListener {
                    emitSignal(SIG_CONSUME_SUCCESS, purchaseToken)
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    emitSignal(SIG_CONSUME_FAILED, code, message)
                }
        } catch (e: Exception) {
            emitSignal(SIG_CONSUME_FAILED, -1, e.message ?: "unknown error")
        }
    }

    /**
     * Queries currently owned (unconsumed / active) purchases.
     * Emits `owned_purchases(json)` with `{"kind":"owned","purchases":[...],"continuation_token":""}`.
     */
    @UsedByGodot
    fun queryOwnedPurchases(priceType: Int, continuationToken: String) {
        val client = requireClient() ?: return
        try {
            val req = OwnedPurchasesReq()
            req.priceType = priceType
            if (continuationToken.isNotEmpty()) {
                req.continuationToken = continuationToken
            }
            client.obtainOwnedPurchases(req)
                .addOnSuccessListener { result ->
                    emitSignal(SIG_OWNED_PURCHASES, packPurchases("owned", result?.inAppPurchaseDataList, result?.continuationToken))
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    emitSignal(SIG_IAP_ERROR, code, "queryOwnedPurchases: $message")
                }
        } catch (e: Exception) {
            emitSignal(SIG_IAP_ERROR, -1, "queryOwnedPurchases: ${e.message}")
        }
    }

    /**
     * Queries the full purchase history (consumed items, expired subscriptions, ...).
     * Emits `owned_purchases(json)` with `{"kind":"history",...}`.
     */
    @UsedByGodot
    fun queryPurchaseHistory(priceType: Int, continuationToken: String) {
        val client = requireClient() ?: return
        try {
            val req = OwnedPurchasesReq()
            req.priceType = priceType
            if (continuationToken.isNotEmpty()) {
                req.continuationToken = continuationToken
            }
            client.obtainOwnedPurchaseRecord(req)
                .addOnSuccessListener { result ->
                    emitSignal(SIG_OWNED_PURCHASES, packPurchases("history", result?.inAppPurchaseDataList, result?.continuationToken))
                }
                .addOnFailureListener { e ->
                    val (code, message) = describeFailure(e)
                    emitSignal(SIG_IAP_ERROR, code, "queryPurchaseHistory: $message")
                }
        } catch (e: Exception) {
            emitSignal(SIG_IAP_ERROR, -1, "queryPurchaseHistory: ${e.message}")
        }
    }

    /** Product-type constants for GDScript (mirror of [IapClient.PriceType]). */
    @UsedByGodot
    fun getTypeConsumable(): Int = TYPE_CONSUMABLE

    @UsedByGodot
    fun getTypeNonConsumable(): Int = TYPE_NON_CONSUMABLE

    @UsedByGodot
    fun getTypeSubscription(): Int = TYPE_SUBSCRIPTION

    // Handles the result of the Huawei IAP checkout page launched by [purchase].
    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != IAP_REQUEST_CODE) {
            return
        }
        if (data == null) {
            emitSignal(SIG_PURCHASE_FAILED, resultCode, "empty checkout result")
            return
        }
        try {
            val hostActivity = activity
            if (hostActivity == null) {
                emitSignal(SIG_PURCHASE_FAILED, -1, "activity unavailable")
                return
            }
            val info = Iap.getIapClient(hostActivity).parsePurchaseResultInfoFromIntent(data)
            when (info.returnCode) {
                OrderStatusCode.ORDER_STATE_SUCCESS -> {
                    val payload = JSONObject()
                    try {
                        val purchaseData = JSONObject(info.inAppPurchaseData ?: "{}")
                        val keys = purchaseData.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            payload.put(key, purchaseData.get(key))
                        }
                    } catch (parseError: Exception) {
                        Log.w(TAG, "Unreadable purchase data, forwarding raw", parseError)
                        payload.put("raw", info.inAppPurchaseData ?: "")
                    }
                    payload.put("signature", info.inAppDataSignature ?: "")
                    payload.put("returnCode", info.returnCode)
                    emitSignal(SIG_PURCHASE_SUCCESS, payload.toString())
                }
                OrderStatusCode.ORDER_STATE_CANCEL -> {
                    emitSignal(SIG_PURCHASE_CANCELLED)
                }
                else -> {
                    val message = info.errMsg?.ifEmpty { "purchase failed" } ?: "purchase failed"
                    emitSignal(SIG_PURCHASE_FAILED, info.returnCode, message)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse checkout result", e)
            emitSignal(SIG_PURCHASE_FAILED, -1, e.message ?: "unknown error")
        }
    }

    private fun requireClient(): IapClient? {
        val client = iapClient
        if (client == null) {
            emitSignal(SIG_IAP_ERROR, -1, "not initialized: call initialize() first")
        }
        return client
    }

    private fun describeFailure(e: Exception): Pair<Int, String> {
        return if (e is IapApiException) {
            e.statusCode to (e.message ?: "IAP error")
        } else {
            -1 to (e.message ?: "unknown error")
        }
    }

    private fun packPurchases(kind: String, dataList: List<String>?, continuationToken: String?): String {
        val purchases = JSONArray()
        dataList?.forEach { raw ->
            try {
                purchases.put(JSONObject(raw))
            } catch (parseError: Exception) {
                Log.w(TAG, "Skipping unreadable purchase entry", parseError)
            }
        }
        return JSONObject()
            .put("kind", kind)
            .put("purchases", purchases)
            .put("continuation_token", continuationToken ?: "")
            .toString()
    }
}
